// /utils/certificate.js
const { exec } = require('child_process');
const path = require('path');

const generateCertificate = (fullName) => {
    return new Promise((resolve, reject) => {
        const certTemplate = path.resolve(__dirname, '../certificates/cert.png');
        const outputFilePath = path.resolve(__dirname, `../certificates/${fullName}.jpg`);
        const command = `magick ${certTemplate} -font "Arial" -pointsize 32 -fill "white" -draw "text 700,490 '${fullName}'" ${outputFilePath}`;

        exec(command, (error) => {
            if (error) {
                return reject(error);
            }
            resolve(outputFilePath);
        });
    });
};

module.exports = { generateCertificate };
