import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.net.InetSocketAddress;
import java.io.InputStream;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.sql.*;

public class BasicHttpServer {

    public static void main(String[] args) throws Exception {
        String ipAddress = "192.168.137.1"; // Set the IP address

        // Create an HTTP server that listens on port 8000
        HttpServer server = HttpServer.create(new InetSocketAddress(ipAddress, 8000), 0);

        // Serve static files (HTML, CSS, Images)
        server.createContext("/", new FileHandler());

        // Handle form submission for login and admin login
        server.createContext("/submitLogin", new LoginHandler());
        server.createContext("/submitAdminLogin", new AdminLoginHandler());

        // Handle form submission for data entry to database
        server.createContext("/submitForm", new FormSubmissionHandler());

        // Handle displaying data on the dashboard
        server.createContext("/dashboard", new DashboardHandler());

        // Start the server
        server.setExecutor(null);
        server.start();
        System.out.println("Server started on port 8000...");
    }

    // Serve static files like HTML, CSS, images
    static class FileHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String filePath = "." + exchange.getRequestURI().getPath();
            if (filePath.equals("./")) {
                filePath = "./index.html"; // Serve index.html by default
            }

            String contentType = getContentType(filePath);

            if (Files.exists(Paths.get(filePath))) {
                byte[] fileBytes = Files.readAllBytes(Paths.get(filePath));
                exchange.getResponseHeaders().add("Content-Type", contentType);
                exchange.sendResponseHeaders(200, fileBytes.length);

                OutputStream os = exchange.getResponseBody();
                os.write(fileBytes);
                os.close();
            } else {
                String errorMessage = "404 File Not Found";
                exchange.sendResponseHeaders(404, errorMessage.length());
                OutputStream os = exchange.getResponseBody();
                os.write(errorMessage.getBytes());
                os.close();
            }
        }

        // Helper method to get content type based on file extension
        private String getContentType(String filePath) {
            if (filePath.endsWith(".html") || filePath.endsWith(".htm")) {
                return "text/html";
            } else if (filePath.endsWith(".css")) {
                return "text/css";
            } else if (filePath.endsWith(".js")) {
                return "application/javascript";
            } else if (filePath.endsWith(".png")) {
                return "image/png";
            } else if (filePath.endsWith(".jpg") || filePath.endsWith(".jpeg")) {
                return "image/jpeg";
            } else {
                return "application/octet-stream";
            }
        }
    }

    // Handler for general user login
    static class LoginHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("POST".equals(exchange.getRequestMethod())) {
                Map<String, String> formData = parseFormData(exchange.getRequestBody());

                String username = formData.get("username");
                String password = formData.get("password");

                if (isValidUser(username, password)) {
                    exchange.getResponseHeaders().set("Location", "/dashboard");
                    exchange.sendResponseHeaders(302, -1); // Redirect to dashboard
                } else {
                    sendResponse(exchange, "Login Failed", "Invalid username or password.");
                }
            }
        }

        private boolean isValidUser(String username, String password) {
            try (Connection con = connectToDatabase()) {
                String sql = "SELECT * FROM StudentsData WHERE idcode = ? AND stdpassword = ?";
                PreparedStatement st = con.prepareStatement(sql);
                st.setString(1, username);
                st.setString(2, password);

                ResultSet rs = st.executeQuery();
                return rs.next();
            } catch (Exception ex) {
                ex.printStackTrace();
                return false;
            }
        }
    }

    // Handler for admin login
    static class AdminLoginHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("POST".equals(exchange.getRequestMethod())) {
                Map<String, String> formData = parseFormData(exchange.getRequestBody());

                String username = formData.get("username");
                String password = formData.get("password");

                if (isAdminValid(username, password)) {
                    exchange.getResponseHeaders().set("Location", "/example.html");
                    exchange.sendResponseHeaders(302, -1); // Redirect to admin dashboard
                } else {
                    sendResponse(exchange, "Admin Login Failed", "Invalid username or password.");
                }
            }
        }

        private boolean isAdminValid(String username, String password) {
            // Hardcoded credentials for testing
            return true;
        }
    }

    // Handler for database form submission
    static class FormSubmissionHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("POST".equals(exchange.getRequestMethod())) {
                // Parse form data from the request body
                Map<String, String> formData = parseFormData(exchange.getRequestBody());

                // Extracting data from form fields (replace with your field names)
                String reason = formData.get("reasonField");
                String name = formData.get("nameField");
                String id = formData.get("idField");
                String email = formData.get("emaillFeild");
                String mobile = formData.get("mobileField");
                String dept = formData.get("deptFeild");
                String address = formData.get("addressField");

                // Insert data into the database
                if (insertIntoDatabase(reason, name, id, email, mobile, dept, address)) {
                    exchange.getResponseHeaders().set("Location", "/submitsuccess.html");
                    exchange.sendResponseHeaders(302, -1);
                } else {
                    sendResponse(exchange, "Error", "Failed to insert data.");
                }
            }
        }

        // Insert data into requestData table
        private boolean insertIntoDatabase(String reason, String name, String id, String email, String mobile, String dept, String address) {
            try (Connection con = connectToDatabase()) {
                // Prepare SQL query for insertion
                String query = "INSERT INTO requestData (reason, stdname, idcode, email, mobileno, dept, address) VALUES (?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement ps = con.prepareStatement(query);
                ps.setString(1, reason);
                ps.setString(2, name);
                ps.setString(3, id);
                ps.setString(4, email);
                ps.setString(5, mobile);
                ps.setString(6, dept);
                ps.setString(7, address);

                // Execute update and check if rows were inserted
                return ps.executeUpdate() > 0;

            } catch (Exception e) {
                e.printStackTrace(); // Log error if occurs
                return false;
            }
        }
    }

    // Handler for displaying the dashboard data
    static class DashboardHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equals(exchange.getRequestMethod())) {
                String response = generateDashboardHTML();
                exchange.getResponseHeaders().set("Content-Type", "text/html");
                exchange.sendResponseHeaders(200, response.length());

                OutputStream os = exchange.getResponseBody();
                os.write(response.getBytes());
                os.close();
            }
        }

        private String generateDashboardHTML() {
            StringBuilder htmlBuilder = new StringBuilder();
         // Start of HTML with embedded CSS
         htmlBuilder.append("<html><head><style>");
         htmlBuilder.append("body { font-family: Arial, sans-serif; background-color: #f4f4f9; color: #333; }");
         htmlBuilder.append("h1 { text-align: center; color: #333; margin-bottom: 20px; }");
         htmlBuilder.append("table { width: 80%; margin: auto; border-collapse: collapse; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }");
         htmlBuilder.append("th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }");
         htmlBuilder.append("th { background-color: #4CAF50; color: white; }");
         htmlBuilder.append("tr:nth-child(even) { background-color: #f2f2f2; }");
         htmlBuilder.append("tr:hover { background-color: #d1e7dd; }");
     
         // CSS for Action icons
         htmlBuilder.append("<html><head><style>");
         htmlBuilder.append("body { font-family: Arial, sans-serif; background-color: #f4f4f9; color: #333; }");
         htmlBuilder.append("h1 { text-align: center; color: #333; margin-bottom: 20px; }");
         htmlBuilder.append("table { width: 80%; margin: auto; border-collapse: collapse; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }");
         htmlBuilder.append("th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }");
         htmlBuilder.append("th { background-color: #4CAF50; color: white; }");
         htmlBuilder.append("tr:nth-child(even) { background-color: #f2f2f2; }");
         htmlBuilder.append("tr:hover { background-color: #d1e7dd; }");
         htmlBuilder.append(".action-link { text-decoration: none; color: white; padding: 5px 10px; border-radius: 4px; }");
         htmlBuilder.append(".approve-link { background-color: #28a745; }");
         htmlBuilder.append(".reject-link { background-color: #dc3545; }");
         htmlBuilder.append("</style></head><body>");
    // Dashboard title and table structure with Action column
    htmlBuilder.append("<h1>Dashboard</h1>");
    htmlBuilder.append("<table>");
    htmlBuilder.append("<tr><th>Application ID</th><th>Name</th><th>ID</th><th>Reason</th><th>Action</th></tr>");
         
            try{
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/clc", "root", "super");
                String sql = "SELECT applicantID, stdname, idcode, reason FROM requestData"; // Corrected column names
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery();

                while (rs.next()) {
                    htmlBuilder.append("<tr>");
                    htmlBuilder.append("<td>").append(rs.getString("applicantID")).append("</td>");
                    htmlBuilder.append("<td>").append(rs.getString("stdname")).append("</td>");
                    htmlBuilder.append("<td>").append(rs.getString("idcode")).append("</td>");
                    htmlBuilder.append("<td>").append(rs.getString("reason")).append("</td>");
                    
                    htmlBuilder.append("<td>");
                    htmlBuilder.append("<a href='/updateStatus?applicantID=").append("applicantID").append("&status=approved' class='action-link approve-link'>Approve</a> ");
                    htmlBuilder.append("<a href='/updateStatus?applicantID=").append("applicantID").append("&status=rejected' class='action-link reject-link'>Reject</a>");
                    htmlBuilder.append("</td>");

            htmlBuilder.append("</tr>");
                    htmlBuilder.append("</tr>");
                }
            } catch (Exception ex) {
                ex.printStackTrace(); // Handle SQL exceptions
                htmlBuilder.append("<tr><td colspan='7'>Error retrieving data.</td></tr>");
            }

            htmlBuilder.append("</table>");
            htmlBuilder.append("</body></html>");
            return htmlBuilder.toString();
        }
    }

    private static Connection connectToDatabase() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/clc", "root", "super");
    }

    // Parse form data from request body
    private static Map<String, String> parseFormData(InputStream requestBody) throws IOException {
        StringBuilder body = new StringBuilder();
        int i;
        while ((i = requestBody.read()) != -1) {
            body.append((char) i);
        }

        String formDataString = URLDecoder.decode(body.toString(), StandardCharsets.UTF_8.name());
        Map<String, String> formData = new HashMap<>();

        for (String pair : formDataString.split("&")) {
            String[] keyValue = pair.split("=");
            if (keyValue.length == 2) {
                formData.put(keyValue[0], keyValue[1]);
            }
        }

        return formData;
    }

    // Send response back to client
    private static void sendResponse(HttpExchange exchange, String title, String message) throws IOException {
        String response = "<html><body><h1>" + title + "</h1><p>" + message + "</p></body></html>";
        exchange.getResponseHeaders().set("Content-Type", "text/html");
        exchange.sendResponseHeaders(200, response.length());

        OutputStream os = exchange.getResponseBody();
        os.write(response.getBytes());
        os.close();
    }
}
