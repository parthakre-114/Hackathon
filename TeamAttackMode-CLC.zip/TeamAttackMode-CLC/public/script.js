// /public/script.js

document.addEventListener('DOMContentLoaded', () => {
    // Form validation example
    const studentForm = document.querySelector('form');
    
    if (studentForm) {
        studentForm.addEventListener('submit', function (event) {
            const fullName = document.querySelector('input[name="fullName"]').value;
            const rollNumber = document.querySelector('input[name="rollNumber"]').value;
            const phoneNumber = document.querySelector('input[name="phoneNumber"]').value;
            const email = document.querySelector('input[name="email"]').value;

            // Basic validation checks
            if (!fullName || !rollNumber || !phoneNumber || !email) {
                alert('Please fill all required fields.');
                event.preventDefault();
            } else if (!validateEmail(email)) {
                alert('Please enter a valid email address.');
                event.preventDefault();
            }
        });
    }
    
    // Email validation
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(String(email).toLowerCase());
    }
});
