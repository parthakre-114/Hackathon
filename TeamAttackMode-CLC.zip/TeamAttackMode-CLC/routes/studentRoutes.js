// /routes/studentRoutes.js
const express = require('express');
const router = express.Router();
const Application = require('../models/Application');

router.get('/dashboard', (req, res) => {
    if (req.session.user && req.session.user.role === 'student') {
        res.sendFile(__dirname + '/../public/student-dashboard.html');
    } else {
        res.redirect('/');
    }
});

router.post('/submitApplication', async (req, res) => {
    const applicationData = {
        fullName: req.body.fullName,
        rollNumber: req.body.rollNumber,
        fatherName: req.body.fatherName,
        motherName: req.body.motherName,
        phoneNumber: req.body.phoneNumber,
        email: req.body.email
    };

    await Application.create(applicationData);
    res.redirect('/student/dashboard');
});

module.exports = router;
