let slideIndex = 0;
let slides = document.getElementsByClassName("carousel-slide");
let totalSlides = slides.length;

function showSlides(n) {
    // Hide all slides
    for (let i = 0; i < totalSlides; i++) {
        slides[i].style.display = "none";
    }
    // Ensure the slide index loops continuously
    slideIndex = (n + totalSlides) % totalSlides;
    slides[slideIndex].style.display = "block";
}

// Function to move to the next slide
function plusSlides(n) {
    showSlides(slideIndex + n);
}

// Auto slide every 3 seconds
function autoSlide() {
    slideIndex++;
    showSlides(slideIndex);
    setTimeout(autoSlide, 3000); // Adjust the interval (in ms)
}

document.addEventListener("DOMContentLoaded", () => {
    showSlides(slideIndex); // Show the first slide initially
    autoSlide(); // Start automatic sliding
});
