// app.js
const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const bcrypt = require('bcrypt');
const bodyParser = require('body-parser');
const User = require('./models/User');
const Application = require('./models/Application');
const { generateCertificate } = require('./utils/certificate');
const app = express();

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('..'));
app.use(session({
    secret: 'yourSecretKey',
    resave: false,
    saveUninitialized: true
}));

// MongoDB Connection
mongoose.connect('mongodb+srv://pdshrote:mongo_atlas@cluster0.4sid9.mongodb.net/', {
    // Remove useNewUrlParser and useUnifiedTopology
})
.then(() => {
    console.log("Connected to MongoDB");
})
.catch((error) => {
    console.error("Error connecting to MongoDB:", error);
});
// Routes
const studentRoutes = require('./routes/studentRoutes');
const adminRoutes = require('./routes/adminRoutes');
app.use('/student', studentRoutes);
app.use('/admin', adminRoutes);

// Login Route
app.post('/login', async (req, res) => {
    const { username, password, role } = req.body;
    const user = await User.findOne({ username, role });

    if (user && await bcrypt.compare(password, user.password)) {
        req.session.user = user;
        return role === 'admin' ? res.redirect('/public/admin-dashboard') : res.redirect('/public/student-dashboard');
    } else {
        return res.send('Invalid credentials');
    }
});

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});


// Listen on port
app.listen(5500, () => {
    console.log('Server is running on port 5500');
});
