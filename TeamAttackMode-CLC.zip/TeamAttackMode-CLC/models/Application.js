// /models/Application.js
const mongoose = require('mongoose');

const applicationSchema = new mongoose.Schema({
    fullName: String,
    rollNumber: String,
    fatherName: String,
    motherName: String,
    phoneNumber: String,
    email: String,
    status: { type: String, default: 'pending' }, // pending, approved, rejected
    rejectionReason: String,
    certificatePath: String
});

module.exports = mongoose.model('Application', applicationSchema);
