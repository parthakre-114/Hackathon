// /routes/adminRoutes.js
const express = require('express');
const router = express.Router();
const Application = require('../models/Application');
const { generateCertificate } = require('../utils/certificate');

router.get('/dashboard', (req, res) => {
    if (req.session.user && req.session.user.role === 'admin') {
        res.sendFile(__dirname + '/../public/admin-dashboard.html');
    } else {
        res.redirect('/');
    }
});

router.get('/requests', async (req, res) => {
    const applications = await Application.find({ status: 'pending' });
    res.json(applications);
});

router.post('/approve/:id', async (req, res) => {
    const application = await Application.findById(req.params.id);
    application.status = 'approved';

    // Generate certificate
    const certificatePath = await generateCertificate(application.fullName);
    application.certificatePath = certificatePath;
    await application.save();

    res.redirect('/admin/requests');
});

router.post('/reject/:id', async (req, res) => {
    const application = await Application.findById(req.params.id);
    application.status = 'rejected';
    application.rejectionReason = req.body.rejectionReason;
    await application.save();

    res.redirect('/admin/requests');
});

module.exports = router;
